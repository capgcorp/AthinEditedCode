package com.cg.uas.ui;

import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.logging.Logger;

import com.cg.uas.dto.Programs_Offered;
import com.cg.uas.dto.Programs_Scheduled;
import com.cg.uas.dto.Application;
import com.cg.uas.dto.Programs_Scheduled;
import com.cg.uas.exception.UasException;
import com.cg.uas.service.IServiceUas;
import com.cg.uas.service.ServiceUasImpl;

public class AdminUI {

	
	public static void updatePrograms()
	{
		Scanner scan=new Scanner(System.in);
		
		
		
		System.out.println("What would you like to do?\n1.Add program offered\n2.Delete program offered");
		int flag=scan.nextInt();
		while(flag!=1 && flag!=2)
		{
			System.out.println("Please enter a valid choice?");
			flag=scan.nextInt();
		}
		try{
			IServiceUas service=new ServiceUasImpl();
		if(flag==1)
		{Programs_Offered por=new Programs_Offered();
		System.out.println("Enter program name");
		scan.nextLine();
		por.setProgramName(scan.nextLine());
		System.out.println("Enter description");
		por.setDescription(scan.nextLine());
		System.out.println("Enter applicant eligibility");
		por.setApplicant_Eligibility(scan.nextLine());
		System.out.println("Enter duration");
		por.setDuration(scan.nextInt());
		System.out.println("Enter degree certificate offered");
		scan.nextLine();
		por.setDegree_Certificate_Offered(scan.nextLine());
		
		
		
			
			boolean res=service.addProgramOffered(por);
		
		if(res)System.out.println("Program offered added");
		else System.out.println("Program not added");
		}
		
		else if(flag==2)
		{
			System.out.println("Enter program name to delete");
			scan.nextLine();
			String ans=scan.nextLine();
			boolean res=service.delProgramOffered(ans);
			if(res)System.out.println("Program deleted");
			else System.out.println("Could not delete");
		}
		
		}catch(UasException e){
			System.out.println(e);
		}
		
		System.out.println("Enter a key to return to main menu");
		scan.nextLine();
		return;
	}
	
	
	
	
	
	
	
	
	public static void manageSchedules()
	{
Scanner scan=new Scanner(System.in);
		
		
		
		System.out.println("What would you like to do?\n1.Add program schedule\n2.Delete program schedule");
		int flag=scan.nextInt();
		while(flag!=1 && flag!=2)
		{
			System.out.println("Please enter a valid choice?");
			flag=scan.nextInt();
		}
		try{
			IServiceUas service=new ServiceUasImpl();
		if(flag==1)
		{Programs_Scheduled por=new Programs_Scheduled();
		System.out.println("Enter program ID");
		por.setScheduled_Program_Id(scan.next());
		scan.nextLine();
		System.out.println("Enter program name");
		por.setProgramName(scan.nextLine());
		System.out.println("Enter city");
		por.setCity(scan.nextLine());
		System.out.println("Enter pincode");
		por.setPincode(scan.nextInt());
		System.out.println("Enter start date(dd/MM/YYYY)");
		scan.nextLine();
		String dateofbirth=scan.nextLine();
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dob=LocalDate.parse(dateofbirth,formatter);
		por.setStart_Date(dob);
		System.out.println("Enter end date(dd/MM/YYYY)");
		dateofbirth=scan.nextLine();
		dob=LocalDate.parse(dateofbirth,formatter);
		por.setEnd_Date(dob);
		System.out.println("Enter sessions per week");
		por.setSessions_Per_Week(scan.nextInt());
		
			System.out.println(por);
			boolean res=service.addProgramScheduled(por);
		
		if(res)System.out.println("Program scheduled added");
		else System.out.println("Program schedule not added");
		}
		
		else if(flag==2)
		{
			scan.nextLine();
			System.out.println("Enter program ID to delete");
			String ans=scan.nextLine();
			boolean res=service.delProgramScheduled(ans);
			if(res)System.out.println("Program schedule deleted");
			else System.out.println("Could not delete schedule");
		}
		
		}catch(UasException e){
			System.out.println(e);
		}
		
		
		System.out.println("Enter a key to return to main menu");
		scan.nextLine();
		return;
	}
	
	
	
	
	
	
	
	public static void generateReports(){
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter what report to generate\n1.View all applicants\n2.View list of programs scheduled to begin in a given period ");
		int flag=scan.nextInt();
		while(flag!=1 && flag!=2)
		{
			System.out.println("Please enter a valid choice");
			flag=scan.nextInt();
		}
		try{
			IServiceUas service=new ServiceUasImpl();
			if(flag==1){
		List<Application> list=service.viewApplicants();
		for(Application a :list)
			System.out.println(a);
			}
			else if(flag==2)
			{System.out.println("Enter Start date of period(dd/mm/yyyy)");
			scan.nextLine();
			String dateofbirth=scan.nextLine();
			DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate dob=LocalDate.parse(dateofbirth,formatter);
			System.out.println("Enter end date of period(dd/mm/yyyy)");
			dateofbirth=scan.nextLine();
			LocalDate dend=LocalDate.parse(dateofbirth,formatter);
			List<Programs_Scheduled> list=service.viewPrograms(dob,dend);
			for(Programs_Scheduled s:list)
				System.out.println(s);
			}
			
		}
		catch(UasException s)
		{System.out.println(s);}
		
		System.out.println("Enter a key to return to main menu");
		scan.nextLine();
		return;
	}
}