package com.cg.uas.ui;

import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.uas.exception.UasException;
import com.cg.uas.service.IServiceUas;
import com.cg.uas.service.ServiceUasImpl;

public class Client {

	
	//Main function showing the first page of UI
	public static void main(String[] args){
		
		PropertyConfigurator.configure("resources/log4j.properties");
		Scanner scan = new Scanner(System.in);
		int opt = 0;
		while(true)
		{
			
		System.out.println("University Admission System");
		System.out.println("---------------------------");
		System.out.println("Choose from the following options");
		System.out.println("1.Applicant");
		System.out.println("2.Members of Admission Committee(MAC)");
		System.out.println("3.Administrators");
		System.out.println("4.Exit");
		
		opt = scan.nextInt();
		switch (opt) {
		case 1:
			applicantfunction();
			break;
		case 2:
			try {
				macfunction();
			} catch (UasException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case 3:
			try {
				adminfunction();
			} catch (UasException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 4:
			System.out.println("Thank you!! Exiting...");
			System.exit(0);
		default:
			System.out.println("Please choose a valid option");
			break;

		}                                             //switch closing
		}                                             //while closing
	}												//main closing
	
	
	
	
	
	
	//The console page showing applicant entry
	public static void applicantfunction()
	{
		Scanner scan = new Scanner(System.in);
		int opt=0;
		boolean repeat=true;
		do{
		
		System.out.println("Applicant Interface");
		System.out.println("-------------------");
		System.out.println("Choose from the following options");
		System.out.println("1.View all programs scheduled by the university");
		System.out.println("2.Apply online for a scheduled program");
		System.out.println("3.View the application status");
		System.out.println("4.Return to main menu");
		System.out.println("5.Exit");
		opt = scan.nextInt();
		switch (opt) {
		case 1:
			repeat=false;
			 ApplicantUi.viewAllPrograms();
			break;
		case 2:
			repeat=false;
			 ApplicantUi.applyForProgram();
			break;
		case 3:
			repeat=false;
			 ApplicantUi.viewApplicationStatus();
			break;
		case 4:
			repeat=false;
			
			System.out.println("Thank you!! returning to main menu...");
			return;
		case 5:
			System.out.println("Thank you!! Exiting...");
			System.exit(0);
		default:
			repeat=true;
			System.out.println("Please choose a valid option");
			

		}       
	}while(repeat==true);
		}  												//function closing
		
		
		

	
	
	
	
	
	
	//The console page showing MAC entry
	public static void macfunction() throws UasException
	
	{
		Scanner scan = new Scanner(System.in);
		int opt=0;
		IServiceUas service=new ServiceUasImpl();
		boolean repeat=true;
		do{
		System.out.println("Welcome to Member of Admission Committee Login");
		System.out.println("Please Enter the userID");
		String name=scan.nextLine();
		System.out.println("Please Enter the password");
		String pwd=scan.nextLine();
		
		
		if(service.macLogin(name,pwd))
		{
		
		System.out.println("MAC Interface");
		System.out.println("-------------");
		System.out.println("Choose from the following options");
		System.out.println("1.View applications for a specific program");
		System.out.println("2.Accept/Reject an application");
		System.out.println("3.Update the status of the application post interview");
		System.out.println("4.Return to main menu");
		System.out.println("5.Exit");
		opt = scan.nextInt();
		switch (opt) {
		case 1:
			repeat=false;
			 MACUI.viewApplications();
			break;
		case 2:
			repeat=false;
			MACUI.processApplication();
			break;
		case 3:
			repeat=false;
			MACUI.updateApplicationStatus();
			break;
		case 4:
			repeat=false;
			
			System.out.println("Thank you!! returning to main menu...");
			return;
		case 5:
			System.out.println("Thank you!! Exiting...");
			System.exit(0);
		default:
			repeat=true;
			System.out.println("Please choose a valid option");
			

		}    
		}
		
		else
		{
			System.out.println("The userID password combination is wrong.Please enter again");
			repeat=true;
		}
	}while(repeat==true);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//The console page showing admin entry
	public static void adminfunction() throws UasException{
		IServiceUas service=new ServiceUasImpl();

		Scanner scan = new Scanner(System.in);
		int opt=0;
		boolean repeat=true;
		do{
		System.out.println("Welcome to Admin Login");
		System.out.println("Please Enter the userID");
		String name=scan.nextLine();
		System.out.println("Please Enter the password");
		String pwd=scan.nextLine();
	
		
		if(service.adminLogin(name, pwd))
		{
		
		System.out.println("Admin Interface");
		System.out.println("---------------");
		System.out.println("Choose from the following options");
		System.out.println("1.Update and manage programs");
		System.out.println("2.Manage schedules of the programs");
		System.out.println("3.Generate reports");
		System.out.println("4.Return to main menu");
		System.out.println("5.Exit");
		opt = scan.nextInt();
		switch (opt) {
		case 1:
             repeat=false;
			 AdminUI.updatePrograms();
			break;
		case 2:repeat=false;
			AdminUI.manageSchedules();
			break;
		case 3:repeat=false;
			AdminUI.generateReports();
			break;
		case 4:repeat=false;
			
			System.out.println("Thank you!! returning to main menu...");
			return;
		case 5:
			System.out.println("Thank you!! Exiting...");
			System.exit(0);
		default:
			repeat=true;
			System.out.println("Please choose a valid option");

		}    
		}
		
		else
		{
			System.out.println("The userID password combination is wrong.Please enter again");
			repeat=true;
		}
		
		}	while(repeat==true);
		
		
	}
	

}
