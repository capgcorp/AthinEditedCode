package com.cg.uas.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.uas.dto.Application;
import com.cg.uas.dto.Programs_Scheduled;
import com.cg.uas.exception.UasException;
import com.cg.uas.service.IServiceUas;
import com.cg.uas.service.ServiceUasImpl;

public class MACUI {

	
	public static void viewApplications()
	{
		String programName=null;
		Scanner scan=new Scanner(System.in);
		IServiceUas service = null;
		try {
			service = new ServiceUasImpl();
		} catch (UasException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Enter the program name to check applications ");
		programName=scan.nextLine();
		try {
			List<Application> list= service.allApplications(programName);
			System.out.println("The Applications for the program  are");
			for(Application s:list)
				System.out.println(s);
		} catch (UasException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Enter a key to return to main menu");
		scan.nextLine();
		return;
		
		
	}
	public static void processApplication()
	
	{
		int appId=0;
		boolean ans=false;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the applicant ID to accept/reject");
		appId=scan.nextInt();
		System.out.println("Accept or reject?(1 or 2)");
		int flag=scan.nextInt();
		scan.nextLine();
		while(flag!=1 && flag!=2)
		{
			System.out.println("Wrong Choice.Enter again");
			flag=scan.nextInt();
		}
		
		
			try {
				IServiceUas service = new ServiceUasImpl();
				if(flag==1){
					System.out.println("Enter interview date(dd/mm/yyyy)");
					String dat=scan.nextLine();
					DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate iDate=LocalDate.parse(dat,formatter);
					
					ans=service.acceptApplication(appId,iDate);
					
					}
				
				else if (flag==2)
					ans=service.rejectApplication(appId);
			} catch (UasException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			 catch (NullPointerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e);
					
				}
			System.out.println("Updated");
			System.out.println("Enter a key to return to main menu");
			scan.nextLine();
			return;		
	
	
	}
		
		
	
	
	public static void updateApplicationStatus()
	{
		int appId=0;
		boolean ans=false;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the application ID to update status");
		appId=scan.nextInt();
		System.out.println("What do you want to do?(Confirm(1) or Reject(2))?");
		System.out.println("Accept or reject?(1 or 2)");
		int flag=scan.nextInt();
		while(flag!=1 && flag!=2)
		{
			System.out.println("Wrong Choice.Enter again");
			flag=scan.nextInt();
		}
		
			try {
				IServiceUas service = new ServiceUasImpl();
				if(flag==1)
				ans=service.confirmApplication(appId);
				else if(flag==2)ans=service.rejectApplication(appId);
			} catch (UasException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Updated");
			System.out.println("Enter a key to return to main menu");
			scan.nextLine();
			return;	
		
		
	}
}