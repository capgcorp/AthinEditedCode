package com.cg.uas.exception;

public class UasException extends Exception {

	private static final long serialVersionUID = 1L;
	public UasException(String msg) {
		super(msg);
	}

}
